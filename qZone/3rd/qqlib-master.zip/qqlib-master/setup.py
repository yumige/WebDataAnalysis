#!python
# coding=utf-8
from distutils.core import setup

setup(
	name='qqlib',
	version='1.0',
	packages=['qqlib'],
	author='Gerald',
	author_email='gera2ld@163.com',
	description='QQ lib for Python 3+.',
	url='http://git.oschina.net/gerald/qqlib',
)
